package models

import org.jetbrains.exposed.sql.Table

// ================= USERS =================
object Users : Table() {
    val id = integer("id").autoIncrement()
    val username = varchar("username", 50)
    val email = varchar("email", 100).uniqueIndex()
    val passwordHash = varchar("password_hash", 255)
    val createdAt = varchar("created_at", 50)

    override val primaryKey = PrimaryKey(id)
}

// ================= FRIENDS =================
object Friends : Table() {
    val userId = integer("user_id").references(Users.id)
    val friendId = integer("friend_id").references(Users.id)
    val status = varchar("status", 20)

    override val primaryKey = PrimaryKey(userId, friendId)
}

// ================= POSTS =================
object Posts : Table() {
    val id = integer("id").autoIncrement()
    val userId = integer("user_id").references(Users.id)
    val content = text("content")
    val createdAt = varchar("created_at", 50)

    override val primaryKey = PrimaryKey(id)
}

// ================= COMMENTS =================
object Comments : Table() {
    val id = integer("id").autoIncrement()
    val postId = integer("post_id").references(Posts.id)
    val userId = integer("user_id").references(Users.id)
    val content = text("content")
    val createdAt = varchar("created_at", 50)

    override val primaryKey = PrimaryKey(id)
}

// ================= LIKES =================
object Likes : Table() {
    val id = integer("id").autoIncrement()
    val userId = integer("user_id").references(Users.id)
    val postId = integer("post_id").references(Posts.id)
    val createdAt = varchar("created_at", 50)

    init {
        uniqueIndex(userId, postId)
    }

    override val primaryKey = PrimaryKey(id)
}