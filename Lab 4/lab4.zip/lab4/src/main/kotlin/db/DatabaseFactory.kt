package db

import org.jetbrains.exposed.sql.Database

object DatabaseFactory {

    fun init() {
        Database.connect(
            url = "jdbc:sqlite:social.db",
            driver = "org.sqlite.JDBC"
        )
    }
}