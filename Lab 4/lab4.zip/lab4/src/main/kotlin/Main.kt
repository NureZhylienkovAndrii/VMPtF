import db.DatabaseFactory
import models.*
import org.jetbrains.exposed.sql.SchemaUtils
import org.jetbrains.exposed.sql.transactions.transaction
import service.SocialService
import service.FeedService

fun main() {

    DatabaseFactory.init()

    transaction {
        SchemaUtils.create(
            Users,
            Friends,
            Posts,
            Comments,
            Likes
        )
    }

    SocialService.createUser("john", "john@mail.com", "123", "2026-06-03")
    SocialService.createUser("anna", "anna@mail.com", "456", "2026-06-03")

    SocialService.createPost(1, "Hello Kotlin social network!", "2026-06-03")

    SocialService.addComment(1, 2, "Nice post!", "2026-06-03")
    SocialService.likePost(2, 1, "2026-06-03")

    println("\n----------------- FEED -----------------\n")

    FeedService.printFeed()
}