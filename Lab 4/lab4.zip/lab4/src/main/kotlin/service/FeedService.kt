package service

import models.*
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction

object FeedService {

    fun printFeed() {
        transaction {

            val posts = Posts.selectAll().toList()

            for (post in posts) {

                val user = Users.select { Users.id eq post[Posts.userId] }.single()

                println("\n📝 POST by ${user[Users.username]}:")
                println(post[Posts.content])

                val comments = Comments.select { Comments.postId eq post[Posts.id] }

                for (comment in comments) {
                    val commentUser = Users.select {
                        Users.id eq comment[Comments.userId]
                    }.single()

                    println("   💬 ${commentUser[Users.username]}: ${comment[Comments.content]}")
                }

                val likesCount = Likes.select {
                    Likes.postId eq post[Posts.id]
                }.count()

                println("   ❤️ Likes: $likesCount")
            }
        }
    }
}