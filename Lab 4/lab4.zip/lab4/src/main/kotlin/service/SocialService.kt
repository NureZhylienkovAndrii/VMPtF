package service

import models.*
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction

object SocialService {

    fun createUser(username: String, email: String, passwordHash: String, createdAt: String) {
        transaction {
            Users.insert {
                it[Users.username] = username
                it[Users.email] = email
                it[Users.passwordHash] = passwordHash
                it[Users.createdAt] = createdAt
            }
        }
    }

    fun getUsers() = transaction {
        Users.selectAll().toList()
    }

    fun createPost(userId: Int, content: String, createdAt: String) {
        transaction {
            Posts.insert {
                it[Posts.userId] = userId
                it[Posts.content] = content
                it[Posts.createdAt] = createdAt
            }
        }
    }

    fun getPosts() = transaction {
        Posts.selectAll().toList()
    }

    fun addComment(postId: Int, userId: Int, content: String, createdAt: String) {
        transaction {
            Comments.insert {
                it[Comments.postId] = postId
                it[Comments.userId] = userId
                it[Comments.content] = content
                it[Comments.createdAt] = createdAt
            }
        }
    }

    fun getComments() = transaction {
        Comments.selectAll().toList()
    }

    fun likePost(userId: Int, postId: Int, createdAt: String) {
        transaction {
            Likes.insert {
                it[Likes.userId] = userId
                it[Likes.postId] = postId
                it[Likes.createdAt] = createdAt
            }
        }
    }

    fun getLikes() = transaction {
        Likes.selectAll().toList()
    }
}