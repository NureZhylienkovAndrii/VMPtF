package com.example.practice

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDate

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etDay = findViewById<EditText>(R.id.etDay)
        val etMonth = findViewById<EditText>(R.id.etMonth)
        val etYear = findViewById<EditText>(R.id.etYear)
        val btnCalc = findViewById<Button>(R.id.btnCalc)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        btnCalc.setOnClickListener {

            val d = etDay.text.toString().toInt()
            val m = etMonth.text.toString().toInt()
            val y = etYear.text.toString().toInt()

            val targetDays = y * 365 + m * 30 + d
            val targetSeconds = targetDays * 24 * 60 * 60 + 12 * 60 * 60

            val baseDays = -366 * 365 - (5 * 30 + 2)
            val baseSeconds = baseDays * 24 * 60 * 60 + 11 * 60 * 60 + 30 * 60

            val diff = targetSeconds - baseSeconds

            tvResult.text = "Пройшло секунд: $diff"
        }
    }
}