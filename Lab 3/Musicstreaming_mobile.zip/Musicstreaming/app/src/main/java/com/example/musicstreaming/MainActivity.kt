package com.example.musicstreaming

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: TrackAdapter

    private lateinit var searchField: EditText
    private lateinit var searchButton: Button
    private lateinit var genreSpinner: Spinner

    private lateinit var allTracks: List<Track>

    private val listenLaterTracks = mutableListOf<Track>()
    private val playlistTracks = mutableListOf<Track>()

    private val genres = listOf("All", "Rock", "Pop")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.rvTracks)
        searchField = findViewById(R.id.etSearch)
        searchButton = findViewById(R.id.btnSearch)
        genreSpinner = findViewById(R.id.spGenre)

        val laterButton = findViewById<Button>(R.id.btnListenLater)
        val playlistButton = findViewById<Button>(R.id.btnMyPlaylist)

        allTracks = listOf(
            Track("Numb", "Linkin Park", "Meteora", "Rock"),
            Track("In The End", "Linkin Park", "Hybrid Theory", "Rock"),
            Track("Believer", "Imagine Dragons", "Evolve", "Rock"),
            Track("Shape of You", "Ed Sheeran", "Divide", "Pop"),
            Track("Blinding Lights", "The Weeknd", "After Hours", "Pop")
        )

        adapter = TrackAdapter(
            allTracks,
            onAddToLater = { track ->
                if (!listenLaterTracks.contains(track)) {
                    listenLaterTracks.add(track)
                    Toast.makeText(this, "${track.title} added to Listen Later", Toast.LENGTH_SHORT).show()
                }
            },
            onAddToPlaylist = { track ->
                if (!playlistTracks.contains(track)) {
                    playlistTracks.add(track)
                    Toast.makeText(this, "${track.title} added to Playlist", Toast.LENGTH_SHORT).show()
                }
            }
        )

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        // SEARCH
        searchButton.setOnClickListener {
            val query = searchField.text.toString().trim().lowercase()

            if (query.isEmpty()) {
                adapter.updateList(allTracks)
                return@setOnClickListener
            }

            val filtered = allTracks.filter {
                it.genre.lowercase().contains(query) ||
                        it.artist.lowercase().contains(query) ||
                        it.album.lowercase().contains(query)
            }

            adapter.updateList(filtered)
        }

        // GENRE SPINNER
        val spinnerAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            genres
        )

        spinnerAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        genreSpinner.adapter = spinnerAdapter

        genreSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    val selected = genres[position]

                    if (selected == "All") {
                        adapter.updateList(allTracks)
                    } else {
                        adapter.updateList(
                            allTracks.filter { it.genre == selected }
                        )
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }

        // LISTEN LATER
        laterButton.setOnClickListener {
            if (listenLaterTracks.isEmpty()) {
                Toast.makeText(this, "Listen Later is empty", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(
                    this,
                    listenLaterTracks.joinToString("\n") { it.title },
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        // PLAYLIST
        playlistButton.setOnClickListener {
            if (playlistTracks.isEmpty()) {
                Toast.makeText(this, "Playlist is empty", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(
                    this,
                    playlistTracks.joinToString("\n") { it.title },
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}