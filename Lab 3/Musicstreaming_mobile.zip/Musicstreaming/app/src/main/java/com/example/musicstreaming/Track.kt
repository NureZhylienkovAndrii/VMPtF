package com.example.musicstreaming

data class Track(
    val title: String,
    val artist: String,
    val album: String,
    val genre: String
)