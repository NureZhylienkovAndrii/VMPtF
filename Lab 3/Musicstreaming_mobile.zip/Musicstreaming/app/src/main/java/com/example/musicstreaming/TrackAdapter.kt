package com.example.musicstreaming

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TrackAdapter(
    private var tracks: List<Track>,
    private val onAddToLater: (Track) -> Unit,
    private val onAddToPlaylist: (Track) -> Unit
) : RecyclerView.Adapter<TrackAdapter.TrackViewHolder>() {

    class TrackViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val title: TextView = itemView.findViewById(R.id.tvTrackTitle)
        val artist: TextView = itemView.findViewById(R.id.tvArtist)
        val album: TextView = itemView.findViewById(R.id.tvAlbum)
        val genre: TextView = itemView.findViewById(R.id.tvGenre)

        val btnLater: Button = itemView.findViewById(R.id.btnLater)
        val btnPlaylist: Button = itemView.findViewById(R.id.btnPlaylist)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TrackViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_track, parent, false)
        return TrackViewHolder(view)
    }

    override fun onBindViewHolder(holder: TrackViewHolder, position: Int) {
        val track = tracks[position]

        holder.title.text = track.title
        holder.artist.text = track.artist
        holder.album.text = track.album
        holder.genre.text = track.genre

        holder.btnLater.setOnClickListener {
            onAddToLater(track)
        }

        holder.btnPlaylist.setOnClickListener {
            onAddToPlaylist(track)
        }
    }

    override fun getItemCount(): Int = tracks.size

    fun updateList(newTracks: List<Track>) {
        tracks = newTracks
        notifyDataSetChanged()
    }
}